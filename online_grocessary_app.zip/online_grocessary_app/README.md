## Create folder online_grocessary_app

online_grocessary_app ---This is my project name


### Create to folder to store images

#create asset folder  and inside create images folder to storage images of items like vegetables,fruits,groceries,dairycproducts under online_grocessary_app folder

### Open lib folder 
write your main code on main.dart
Click on ctrl+S to save 

#### Open pubspec.yaml
Add dependencies and version 
Click on ctrl+S to save 

#### Open terminal
flutter run 

# Choose device
If used to select chrome click on 2

Shopping cart application will be shown 
Displayed with items and prices


