package com.example.online_grocessary_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
